/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class CharDemo {
    public static void main(String args[])  {
        char ch1,ch2;
        ch1=88;
        ch2='Y';
        System.out.print("ch1 and ch2: ");
        System.out.println(ch1+" "+ch2);
    }

}
