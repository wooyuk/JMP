/**
 *  Just for fun
 * 
 */
public class ForTick2 {
    public static void main(String args[])  {

        //here, n is declared inside of the loop
        for(int n=10; n>0; n--)
            System.out.println("tick " + n);
    }
}
