/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class Area {
    public static void main(String args[])  {
        double pi,r,a;
        r=10.8;
        pi=3.1416;
        a=pi*r*r;
        System.out.println("Area of circle is "+a);
    }

}
