/**
 *  Just for fun
 * 
 */
public class DoWhlie {
    public static void main(String args[])  {
        int n = 10;

        do
        {
            System.out.println("tick " + n);
            n--;
        }  while (n > 0);
        /*  do
         * {
         *     System.out.println("tick " + n);
         * }  while(--n > 0);
         */
    }
}
