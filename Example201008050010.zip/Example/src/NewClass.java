/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
class Example  {
  public static void main(String args[])  {
 System.out.println("This is a simple Java program.\n你好，JAVA！");
  }
}

