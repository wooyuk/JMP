/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class ForTest {
    public static void main(String args[])  {
        int x;
        for(x=0;x<10;x=x+1)
            System.out.println("This is x:"+x);
    }

}
